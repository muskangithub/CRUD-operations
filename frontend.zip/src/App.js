import React from 'react'
import './App.css'
import {Route, BrowserRouter, Routes} from "react-router-dom"
import Login from './components/login';
import Register from './components/register';
import Home from './components/home';
import Home2 from './components/home2';
import Table from './components/table';
import Registernew from './components/registerNew';
// import PrivateComponent from './components/private';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Home/>
      <Routes>
      {/* <Route element={<PrivateComponent/>}> */}
      
      
      <Route path="home2" element={<Home2 />} />
      <Route path="table" element={<Table />} />
      <Route path="registerNew/:id" element={<Registernew />} />
      {/* </Route> */}
      <Route path="register" element={<Register />} />
      <Route path="login" element={<Login />} />
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
