import React, { useEffect, useState } from 'react';
import "../assets/css/style.css"
import {useNavigate} from 'react-router-dom';

export default function Register() {
 
  const [name,setName]=useState("");
  const [email,setEmail]=useState("")
  const [password,setPassword]=useState("")
  const navigate=useNavigate();

  // useEffect(()=>{
  //   const User1=localStorage.getItem("user");
  //   if(User1){
  //     navigate('/login')
  //   }
  // },[])

  
    const collectData =async()=>{
      console.log(name,email,password);
      let result=await fetch("http://localhost:5000/register",{
        method: 'post',
        body :JSON.stringify({name,email,password}),
        headers:{
          'Content-Type':'application/json'
        }
      });
      result=await result.json();
        console.log(result);
        if(result.name){
          const test=result.email
          if(!test.includes("@gmail.com")){
            alert("email must contain @gmail.com")
          }else{
            localStorage.setItem("user",JSON.stringify(result))
            navigate('/login')
            }
          }
      else{
        alert('That email already exists!')
      }
  }

  const handleChange=(e)=>{
    setEmail(e.target.value)
  }
    


  return (
    <div className="Login">
      <h1>REGISTER</h1>
      <label>
        <p className="p1">Username :</p>
        <input type="text" placeholder="Name" value={name} onChange={(e)=>setName(e.target.value)} name="name"  />
      </label>
      <label>
        <p className="p1">Password :</p>
        <input type="text" placeholder="Password"  value={password} onChange={(e)=>setPassword(e.target.value)} name="Password" />
      </label>
      <label>
        <p className="p1">E-mail :</p>
        <input type="text" placeholder="E-mail" value={email} onChange={handleChange} />
      </label>
      <div>
        <button type="submit" className="btn" onClick={collectData} >REGISTER</button>

      </div>
    </div>
  )
}