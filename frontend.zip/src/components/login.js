import React, { useState, useEffect } from 'react';
import { Link, useNavigate,useParams } from 'react-router-dom';
import "../assets/css/style.css"

export default function Login() {

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const params=useParams();
  // const [state, setstate] = useState("")
  const navigate = useNavigate();

  // useEffect(()=>{

  // },[])

  const dataLogin = async () => {
    console.log(email, password);
    let result = await fetch("http://localhost:5000/login", {
      method: 'post',
      body: JSON.stringify({ email, password }),
      headers: {
        'Content-Type': 'application/json'
      }
    });
    result = await result.json();
    console.log(result);
    const User1 = localStorage.getItem('user')
    if (result.name) {
      localStorage.setItem("user",JSON.stringify(result))
      // alert("user already exist")
      navigate('/table')
    }
      // const test=getProductDetail()
       
      else if (User1 ) {
        navigate('/table')
      }
      // else if(getProductDetail() ){
      //   alert("user already exist")
      // }
      else if(!User1){
        alert("First register the user")
        navigate('/register')
        }
      // localStorage.setItem("user",JSON.stringify(result))
      else {
      alert("incorrect details")
    }

  // const  getProductDetail=async()=>{
  //   let result=await fetch(`http://localhost:5000/user/${params.id}`);
  //     result=await result.json();
  //     console.log(result)
  //     if(result){
  //       localStorage.setItem("user",JSON.stringify(result))
  //     }
      
      // if(result){
      //   alert("user already exist")
      // }
      // setName(result.name)
      // setEmail(result.email)
      // setPassword(result.password)
  }




  return (
    <div className="Login">
      <h1>LOGIN</h1>
      <label>
        <p className="p1">E-mail :</p>
        <input type="text" placeholder="E-mail" value={email} onChange={(e) => setEmail(e.target.value)} name="E-mail" />
      </label>
      <label>
        <p className="p1">Password :</p>
        <input type="text" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} name="Password" />
      </label>
      <div>
        <button type="submit" className="btn" onClick={dataLogin}>Submit</button>
      </div>
      <p>Don't have any aacount? <Link to="/register">Register</Link></p>
    </div>
  )
}