// import React from 'react';
// import {Navigate, Outlet} from 'react-router-dom'

// export default function PrivateComponent() {
//     const User1=localStorage.getItem("user");
//     return User1? <Outlet/>: <Navigate to='register'/>
// }