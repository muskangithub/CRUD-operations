import React, { useState , useEffect} from 'react';
import "../assets/css/style.css"
import {useNavigate,useParams} from 'react-router-dom';


export default function Registernew() {
 
  const [name,setName]=useState("");
  const [email,setEmail]=useState("")
  const [password,setPassword]=useState("")
  const navigate=useNavigate();
  const params=useParams();

   useEffect(()=>{
    getProductDetail();
  },[])


  const  getProductDetail=async()=>{
    let result=await fetch(`http://localhost:5000/user/${params.id}`);
      result=await result.json();
      setName(result.name)
      setEmail(result.email)
      setPassword(result.password)
  }

  const updateRecord = async()=>{
   
    let result=await fetch(`http://localhost:5000/user/edit/${params.id}`,{
      method: 'put', 
      body :JSON.stringify({name,email,password}),
      headers:{
        'Accept':'application/json',
        'content-type':'application/json'
      }
    });
    result=await result.json();
    if(result){
      navigate('/table')
    }
  }

  

  return (
    <div className="Login">
      <h1>UPDATE USER</h1>
      <label>
        <p className="p1">Username :</p>
        <input type="text" placeholder="Name" value={name} onChange={(e)=>setName(e.target.value)} name="name"  />
      </label>
      <label>
        <p className="p1">Password :</p>
        <input type="text" placeholder="Password"  value={password} onChange={(e)=>setPassword(e.target.value)} name="Password" />
      </label>
      <label>
        <p className="p1">E-mail :</p>
        <input type="text" placeholder="E-mail" value={email} onChange={(e)=>setEmail(e.target.value)} />
      </label>
      <div>
        <button type="submit" className="btn" onClick={()=>{updateRecord()}} >UPDATE</button>

      </div>
    </div>
  )
}