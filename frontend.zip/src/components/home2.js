import React from 'react';
import "../assets/css/style.css"

export default function Home2() {
    return(
        <div>
        <h1> welcome !</h1>
        <p>This is the home page</p>
        </div>
    )
}
