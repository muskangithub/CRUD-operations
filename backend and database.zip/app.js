const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
require('./db/config');
const user=require('./db/user');
const app=express();

app.use(express.json());
app.use(cors());
app.set('view engine','ejs')


// routes 
app.get('/',(req,resp)=>{
   resp.render('table');
})

app.post("/register",async (req,resp)=>{

   let User = await user.findOne({ email: req.body.email });
   if (User) {
       resp.send({ result: " user email already exist" });
       
  }else{
      let User=new user(req.body)
      let result=await User.save();
      result=result.toObject();
      resp.send(result)
  }
  
 })
 
 app.get("/user",async (req,resp)=>{
  
      let User = await user.find();
            resp.send(User) 
 })

 app.post("/login",async (req,resp)=>{
    if (req.body.password && req.body.email) {
       let User = await user.findOne(req.body).select("-password");
       if (User) {
          resp.send(User)
          resp.render("home2")
       } else {
          resp.send({ result: "no user found" })
       }
    }
   else {
          resp.send({ result: "invalid inputs" })
       }    
 })
 

 //delete from table
 app.delete("/userdelete/:id",async(req,resp)=>{
   
   let User = await user.deleteOne({_id:req.params.id}) 
   resp.send(User)
 });
  

 //update user data
 app.put('/user/edit/:id', async(req, resp)=>{
   const User = await user.updateOne(
       {_id: req.params.id},
       {$set: req.body}
   )
   resp.send(User)
});

//GET for single user
app.get("/user/:id",async (req,resp)=>{
  
   let User = await user.findOne({_id: req.params.id});
   if(User){
      resp.send(User)
   }else{
      resp.send({'user':'not found'})
   }
         
})
  
   app.listen(5000);
